package LibraryMangementSystemApplication;

public interface LibraryOperations {

    void addBook(Book book) throws LibraryException;
    void viewBooks();
    void issueBook(int book_id) throws LibraryException;
    void returnBook(int book_id) throws LibraryException;
}
