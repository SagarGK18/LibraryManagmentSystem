package LibraryMangementSystemApplication;

public class Student extends User {

    public Student(int userId, String name) {
        super(userId, name);
    }

   
    public void showRole() {
        System.out.println("Role: Student");
    }
}
