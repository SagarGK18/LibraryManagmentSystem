package LibraryMangementSystemApplication;

public class Book {

    int bookId;
    String title;
    String author;
    boolean issued;

    public Book(int bookId, String title, String author, boolean issued) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.issued = issued; 
    }

    public void issueBook() {
        issued = true;
    }

    public void returnBook() {
        issued = false;
    }

    public String toString() {
        return bookId + "  " + title + "  " + author + "  " + (issued ? "Issued" : "Available");
    }
}
