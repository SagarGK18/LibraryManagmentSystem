package LibraryMangementSystemApplication;

import java.util.LinkedList;

public class Library implements LibraryOperations {

    LinkedList<Book> books = new LinkedList<>();

    public Library() {
        books.add(new Book(1, "Java Basics", "John Doe", false));
        books.add(new Book(2, "Python 101", "Jane Smith", false));
        books.add(new Book(3, "Data Structures", "Mike Brown", false));
        books.add(new Book(4, "Algorithms", "Alice Green", false));
        books.add(new Book(5, "Database Systems", "Robert White", false));
    }

    
    public void addBook(Book book) throws LibraryException {
        for (Book b : books) {   // loop variable must be different
            if (b.bookId == book.bookId) {
                throw new LibraryException("Book ID already exists!");
            }
        }
        books.add(book);
        System.out.println("Book added successfully.");
    }

    
    public void viewBooks() {
        if (books.isEmpty()) {
            System.out.println("No books available.");
            return;
        }
        System.out.println("ID  Title  Author  Status");
        for (Book book : books) {
            System.out.println(book);
        }
    }

    
    public void issueBook(int id) throws LibraryException {
        for (Book book : books) {
            if (book.bookId == id) {
                if (book.issued) {
                    throw new LibraryException("Book already issued!");
                } else {
                    book.issueBook();
                    System.out.println("Book issued.");
                }
                return;
            }
        }
        throw new LibraryException("Book not found!");
    }

    
    public void returnBook(int id) throws LibraryException {
        for (Book book : books) {
            if (book.bookId == id) {
                if (!book.issued) {
                    throw new LibraryException("Book is not issued!");
                } else {
                    book.returnBook();
                    System.out.println("Book returned.");
                }
                return;
            }
        }
        throw new LibraryException("Book not found!");
    }
}
