package LibraryMangementSystemApplication;

import java.util.Scanner;

public class LibraryMangementSystem {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        LibraryOperations library = new Library(); 

        System.out.println("Welcome to Library Management System!");
        System.out.println("Select role: 1. Student  2. Librarian");
        int role = scanner.nextInt();
        scanner.nextLine(); 
        User currentUser;
        if (role == 1) {
            currentUser = new Student(1, "Amit");
        } else if (role == 2) {
            currentUser = new Librarian(2, "Admin");
        } else {
            System.out.println("Invalid role selected.");
            scanner.close();
            return;
        }

        currentUser.showRole();

        int choice = 0;

        do {
            try {
                if (currentUser instanceof Librarian) {
                    System.out.println("\n1. Add Book  2. View Books  3. Issue Book  4. Return Book  5. Exit");
                    System.out.print("Enter choice: ");
                    choice = scanner.nextInt();
                    scanner.nextLine();

                    switch (choice) {
                        case 1:
                            System.out.print("Enter Book ID: ");
                            int id = scanner.nextInt();
                            scanner.nextLine();
                            System.out.print("Enter Title: ");
                            String title = scanner.nextLine();
                            System.out.print("Enter Author: ");
                            String author = scanner.nextLine();

                          
                            try {
                                library.addBook(new Book(id, title, author, false));
                            } catch (LibraryException e) {
                                System.out.println("Error: " + e.getMessage());
                            }
                            break;

                        case 2:
                            library.viewBooks();
                            break;

                        case 3:
                            System.out.print("Enter Book ID to issue: ");
                            int issueId = scanner.nextInt();

                            try {
                                library.issueBook(issueId);
                            } catch (LibraryException e) {
                                System.out.println("Error: " + e.getMessage());
                            }
                            break;

                        case 4:
                            System.out.print("Enter Book ID to return: ");
                            int returnId = scanner.nextInt();

                            try {
                                library.returnBook(returnId);
                            } catch (LibraryException e) {
                                System.out.println("Error: " + e.getMessage());
                            }
                            break;

                        case 5:
                            System.out.println("Exiting system...");
                            break;

                        default:
                            System.out.println("Invalid choice!");
                    }

                } else { 
                    System.out.println("1.View Books  2. Exit");
                    System.out.print("Enter choice: ");
                    choice = scanner.nextInt();
                    scanner.nextLine();

                    switch (choice) {
                        case 1:
                            library.viewBooks();
                            break;
                        case 2:
                            System.out.println("Exiting system...");
                            break;
                        default:
                            System.out.println("Invalid choice!");
                    }
                }

            } catch (Exception e) {
                System.out.println("Invalid input! Enter numbers only.");
                scanner.nextLine(); 
            }

        } while ((currentUser instanceof Librarian && choice != 5) ||
                 (currentUser instanceof Student && choice != 2));

        scanner.close();
    }
}
