package LibraryMangementSystemApplication;

public class Librarian extends User {

    public Librarian(int userId, String name) {
        super(userId, name);
    }

    
    public void showRole() {
        System.out.println("Role: Librarian");
    }
}
